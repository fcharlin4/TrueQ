# Punto de entrada para el backend de trueQ

def main():
    print("Bienvenido a trueQ - Plataforma de trueques")

if __name__ == "__main__":
    main()
