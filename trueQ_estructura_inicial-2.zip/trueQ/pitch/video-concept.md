# Guion para video conceptual de trueQ

## Escena 1
Una persona tiene una bicicleta que ya no usa.

## Escena 2
Otra persona necesita una bicicleta y ofrece clases de guitarra.

## Escena 3
Ambos se encuentran en trueQ, negocian y hacen el intercambio.

## Escena 4
Narrador: "trueQ, la app que conecta personas para intercambiar lo que tienen por lo que necesitan."
