# MVP de trueQ

Este documento define las funcionalidades mínimas necesarias para lanzar la primera versión de trueQ.

## Funcionalidades clave

- Autenticación de usuarios
- Publicación de ofertas de trueque
- Visualización de feed de trueques
- Búsqueda por categoría y ubicación
- Chat para negociación
