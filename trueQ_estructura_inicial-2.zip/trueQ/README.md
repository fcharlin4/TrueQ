# trueQ

trueQ es una plataforma global para facilitar el intercambio de bienes y servicios entre personas mediante trueques. El objetivo es fomentar una economía colaborativa y sostenible.

## MVP (Producto Mínimo Viable)

- Registro y login de usuarios
- Feed de publicaciones de trueques
- Perfil de usuario con historial de intercambios
- Sistema de búsqueda y filtros
- Chat entre usuarios para negociar trueques

## Cómo contribuir

1. Haz un fork del repositorio
2. Crea una rama con tu funcionalidad: `git checkout -b feature/nombre`
3. Haz commit de tus cambios: `git commit -m 'Agrega nueva funcionalidad'`
4. Haz push a la rama: `git push origin feature/nombre`
5. Abre un Pull Request
