# trueQ
Plataforma global de trueques entre personas.

## Estructura del proyecto
- `docs/`: Documentación del MVP
- `design/`: Prototipos y enlaces de Figma
- `pitch/`: Guion del video conceptual
- `src/`: Código fuente